import json
import boto3

def create_instance(event, context):
    ec2 = boto3.resource('ec2')

    # event['body'] is a string, so we need to convert it to JSON
    body = json.loads(event['body'])

    instance_type = body['instance_type']
    subnet_id = body['subnet_id']
    security_group_id = body['security_group_id']
    key_pair_name = body['key_pair_name']
    ami_id = body['ami_id']

    user_data = """
    #!/bin/bash
    sudo apt update
    sudo apt install -y nginx
    sudo systemctl start nginx
    """

    # Create the instance without specifying the subnet ID
    instances = ec2.create_instances(
        ImageId=ami_id,
        MinCount=1,
        MaxCount=1,
        InstanceType=instance_type,
        KeyName=key_pair_name,
        NetworkInterfaces=[
            {
                'DeviceIndex': 0,
                'SubnetId': subnet_id,
                'Groups': [security_group_id],
                'AssociatePublicIpAddress': True
            }
        ]
    )

    # Wait for the instance to be running
    instances[0].wait_until_running()

    # Attach the instance to the specified subnet
    instances[0].modify_attribute(Groups=[security_group_id])

    return {
        "statusCode": 200,
        "body": json.dumps({
            "instanceId": instances[0].id,
        }),
    }
